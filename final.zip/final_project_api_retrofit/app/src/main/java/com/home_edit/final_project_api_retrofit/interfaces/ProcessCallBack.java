package com.home_edit.final_project_api_retrofit.interfaces;

public interface ProcessCallBack  {

    void onSuccess (String message);
    void onFailure(String message);
}
