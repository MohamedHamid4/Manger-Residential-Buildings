package com.home_edit.final_project_api_retrofit.interfaces;

import java.util.List;

public interface ListCalBack <T>{
    void onSuccess (List<T> list);
    void onFailure (String message);
}
