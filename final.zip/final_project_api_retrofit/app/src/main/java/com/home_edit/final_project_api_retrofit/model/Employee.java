package com.home_edit.final_project_api_retrofit.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.home_edit.final_project_api_retrofit.api.ApiController;
import com.home_edit.final_project_api_retrofit.interfaces.ListCalBack;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Employee {

    @SerializedName("id")
    @Expose
    public Integer id;
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("mobile")
    @Expose
    public String mobile;
    @SerializedName("national_number")
    @Expose
    public String nationalNumber;
    @SerializedName("active")
    @Expose
    public Boolean active;
    @SerializedName("image_url")
    @Expose
    public String imageUrl;


    public long mobiles;
    public long nationalNumbers;

    public byte[] imagesByteArray;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getNationalNumber() {
        return nationalNumber;
    }

    public void setNationalNumber(String nationalNumber) {
        this.nationalNumber = nationalNumber;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public long getMobiles() {
        return mobiles;
    }

    public void setMobiles(long mobiles) {
        this.mobiles = mobiles;
    }

    public long getNationalNumbers() {
        return nationalNumbers;
    }

    public void setNationalNumbers(long nationalNumbers) {
        this.nationalNumbers = nationalNumbers;
    }

    public byte[] getImagesByteArray() {
        return imagesByteArray;
    }

    public void setImagesByteArray(byte[] imagesByteArray) {
        this.imagesByteArray = imagesByteArray;
    }

    public void createEmployee(ProcessCallBack callBack) {
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), imagesByteArray);
        MultipartBody.Part file = MultipartBody.Part.createFormData("image", "image-file", requestBody);
        Call<BaseResponse> call = ApiController.getInstance().getRetrofitRequest().createEmployee(name, mobiles, nationalNumbers, file);
        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callBack.onSuccess(response.body().message);


                } else {
                    try {
                        String error = new String(response.errorBody().bytes(), StandardCharsets.UTF_8);
                        JSONObject jsonObject = new JSONObject(error);
                        callBack.onFailure(jsonObject.getString("message"));
                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {

            }
        });

    }

    public  static void getEmployee(ListCalBack<Employee> listCalBack) {
        Call<BaseResponse<Employee>> call = ApiController.getInstance().getRetrofitRequest().getEmployee();
        call.enqueue(new Callback<BaseResponse<Employee>>() {
            @Override
            public void onResponse(Call<BaseResponse<Employee>> call, Response<BaseResponse<Employee>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    listCalBack.onSuccess(response.body().list);

                }
            }

            @Override
            public void onFailure(Call<BaseResponse<Employee>> call, Throwable t) {

            }
        });
    }

    public void delete(ProcessCallBack callback) {
        Call<BaseResponse> call = ApiController.getInstance().getRetrofitRequest().deleteEmployee(id.toString());
        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful() && response.body() != null){
                    callback.onSuccess(response.body().message);
                }else {
                    try {
                        String error = new String(response.errorBody().bytes(), StandardCharsets.UTF_8);
                        JSONObject jsonObject = new JSONObject(error);
                        callback.onFailure(jsonObject.getString("message"));
                        callback.onFailure("");
                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {

            }
        });
    }


    public void update(ProcessCallBack callback) {
        Call<BaseResponse> call = ApiController.getInstance().getRetrofitRequest().updateEmployee(id,name,mobile,nationalNumber);
        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onSuccess(response.body().message);
                } else {
                    try {
                        String error = new String(response.errorBody().bytes(), StandardCharsets.UTF_8);
                        JSONObject jsonObject = new JSONObject(error);
                        callback.onFailure(jsonObject.getString("message"));
                    } catch (IOException | JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                callback.onFailure("");
            }
        });
    }




}
