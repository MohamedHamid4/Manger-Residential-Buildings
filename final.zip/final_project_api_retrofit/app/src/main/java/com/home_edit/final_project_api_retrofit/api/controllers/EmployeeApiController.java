package com.home_edit.final_project_api_retrofit.api.controllers;

import com.home_edit.final_project_api_retrofit.interfaces.ListCalBack;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;
import com.home_edit.final_project_api_retrofit.model.Employee;

public class EmployeeApiController {

    public void createEmployee(String name, long mobile, long national_number, byte[] b, ProcessCallBack callBack) {


        Employee employee = new Employee();
        employee.name = name;
        employee.mobiles = mobile;
        employee.nationalNumbers = national_number;
        employee.imagesByteArray = b;
        employee.createEmployee(callBack);
    }

    public void getEmployee (ListCalBack <Employee> listCalBack){
        Employee.getEmployee(listCalBack);
    }

    public void delete(Employee employee , ProcessCallBack callback ){
        employee.delete(callback);
    }
    public void update(Employee employee , ProcessCallBack callback){
        if (employee.name != null && employee.mobile != null && employee.nationalNumber != null){
            employee.update(callback);
        }else {
            callback.onFailure("Enter required data!");
        }
    }
}




