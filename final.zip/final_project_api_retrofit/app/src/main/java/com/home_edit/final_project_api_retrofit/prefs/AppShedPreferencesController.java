package com.home_edit.final_project_api_retrofit.prefs;

import android.content.Context;
import android.content.SharedPreferences;

import com.home_edit.final_project_api_retrofit.model.Admin;


enum prefKeys {
    loggedIn, id, name, towerName, email, token
}

public class AppShedPreferencesController {

    public static AppShedPreferencesController instance;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private AppShedPreferencesController(Context context) {
        sharedPreferences = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
    }

    public static synchronized AppShedPreferencesController getInstance(Context context) {
        if (instance == null) {
            instance = new AppShedPreferencesController(context);
        }
        return instance;
    }

    public String getToken() {
        return sharedPreferences.getString(prefKeys.token.name(), "");
    }

    public void save(Admin admin) {
        editor = sharedPreferences.edit();
        editor.putBoolean(prefKeys.loggedIn.name(), true);
        editor.putInt(prefKeys.id.name(), admin.id);
        editor.putString(prefKeys.name.name(), admin.name);
        editor.putString(prefKeys.email.name(), admin.email);
        editor.putString(prefKeys.towerName.name(), admin.towerName);
        editor.putString(prefKeys.token.name(), "Bearer "+ admin.token);
        editor.apply();

    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(prefKeys.loggedIn.name(), false);
    }

    public void clear() {
        editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }


}
