package com.home_edit.final_project_api_retrofit.api;


import com.home_edit.final_project_api_retrofit.AppController;
import com.home_edit.final_project_api_retrofit.model.Admin;
import com.home_edit.final_project_api_retrofit.prefs.AppShedPreferencesController;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitSetting {


    private static Retrofit retrofit;
    private static final String BASE_URI = "https://towers.mr-dev.tech/api/";

    private RetrofitSetting() {
    }


    public static synchronized Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            OkHttpClient okHttpClient = buildHttpClient();
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URI)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }


    private static OkHttpClient buildHttpClient() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request.Builder builder = chain.request().newBuilder();
                           String token = AppShedPreferencesController.getInstance(AppController.getInstance()).getToken();
                        if (!token.isEmpty()) {
                            builder.addHeader("Authorization", token);
                        }
                        builder.addHeader("Accept", "application/json");
                        builder.addHeader("Content-Type", "application/json");
                        builder.build();
                        return chain.proceed(builder.build());
                    }
                })
                .build();
        return okHttpClient;
    }

}
