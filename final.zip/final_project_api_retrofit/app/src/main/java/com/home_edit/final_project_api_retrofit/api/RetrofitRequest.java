package com.home_edit.final_project_api_retrofit.api;


import com.home_edit.final_project_api_retrofit.model.Admin;
import com.home_edit.final_project_api_retrofit.model.BaseResponse;
import com.home_edit.final_project_api_retrofit.model.Employee;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;


public interface RetrofitRequest {


    @FormUrlEncoded
    @POST("auth/login")
    Call<BaseResponse<Admin>> login(@Field("email") String email, @Field("password") String password);

    @GET("auth/logout")
    Call<BaseResponse> logout();

    @Multipart
    @POST("employees")
    Call<BaseResponse> createEmployee(@Part("name") String name, @Part("mobile") long mobile, @Part("national_number") long national_number, @Part MultipartBody.Part image);

    @GET("employees")
    Call<BaseResponse<Employee>> getEmployee();

    @DELETE("employees/{id}")
    Call<BaseResponse> deleteEmployee(@Path("id") String id);

    @Multipart
    @POST("employees/{id}")
    Call<BaseResponse> updateEmployee(@Path("id") int id, @Part("name") String name, @Part("mobile") String mobile, @Part("national_number") String national_number);

}
