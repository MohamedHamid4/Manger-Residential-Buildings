package com.home_edit.final_project_api_retrofit.api.controllers;

import com.home_edit.final_project_api_retrofit.AppController;
import com.home_edit.final_project_api_retrofit.api.ApiController;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;
import com.home_edit.final_project_api_retrofit.model.Admin;
import com.home_edit.final_project_api_retrofit.model.BaseResponse;
import com.home_edit.final_project_api_retrofit.prefs.AppShedPreferencesController;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AuthApiController {
    public void login(String email, String password, ProcessCallBack callBack) {
        if (!email.trim().isEmpty() && !password.trim().isEmpty()) {
            Admin admin = new Admin();
            admin.email = email;
            admin.password = password;
            admin.login(callBack);
        } else
            callBack.onFailure("enter required data!");
    }

    public void logout(ProcessCallBack callBack) {
        Call<BaseResponse> call = ApiController.getInstance().getRetrofitRequest().logout();
        call.enqueue(new Callback<BaseResponse>() {
            @Override
            public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                if (response.isSuccessful()) {
                    AppShedPreferencesController.getInstance(AppController.getInstance()).clear();
                    if (response.code() == 200 || response.code() == 401) {
                        AppShedPreferencesController.getInstance(AppController.getInstance()).clear();
                        callBack.onSuccess(response.code() == 200 ? response.body().message : "Logged out successfully");
                }


                }

            }

            @Override
            public void onFailure(Call<BaseResponse> call, Throwable t) {
                callBack.onFailure(t.getMessage());
            }
        });
    }


}

