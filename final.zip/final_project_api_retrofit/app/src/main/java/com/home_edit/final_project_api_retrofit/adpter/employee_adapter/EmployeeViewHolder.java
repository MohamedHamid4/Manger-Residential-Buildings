package com.home_edit.final_project_api_retrofit.adpter.employee_adapter;

import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.home_edit.final_project_api_retrofit.AppController;
import com.home_edit.final_project_api_retrofit.R;
import com.home_edit.final_project_api_retrofit.databinding.ItemEmployeeBinding;
import com.home_edit.final_project_api_retrofit.enums.ActionType;
import com.home_edit.final_project_api_retrofit.interfaces.TaskCallBack;
import com.home_edit.final_project_api_retrofit.model.Employee;


public class EmployeeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    ItemEmployeeBinding binding;
    TaskCallBack callBack;
    Employee employee;

    public EmployeeViewHolder(@NonNull ItemEmployeeBinding binding, TaskCallBack callBack) {
        super(binding.getRoot());
        this.binding = binding;
        this.callBack = callBack;
        setOnClickListener();


    }
    public void setEmployee (Employee employee){
        this.employee = employee;
        binding.nameEmployeeTextView.setText(employee.getName());
        binding.mobileEmployeeView.setText(employee.getMobile());

    }

    private void setOnClickListener(){
        binding.deleteA.setOnClickListener(this);
        binding.updateA.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.delete_a){
                callBack.onActionCallBack(ActionType.delete,getAdapterPosition(),employee.id);
            }else if (view.getId() == R.id.update_a){
                if (callBack != null){
                    callBack.onActionCallBack(ActionType.update,getAdapterPosition(),employee.id);
                }
            }
        }
    }
