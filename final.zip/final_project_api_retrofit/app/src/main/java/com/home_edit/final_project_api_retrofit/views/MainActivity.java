package com.home_edit.final_project_api_retrofit.views;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.home_edit.final_project_api_retrofit.R;
import com.home_edit.final_project_api_retrofit.api.controllers.AuthApiController;
import com.home_edit.final_project_api_retrofit.api.controllers.EmployeeApiController;
import com.home_edit.final_project_api_retrofit.databinding.ActivityMainBinding;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;
import com.home_edit.final_project_api_retrofit.model.Employee;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    AuthApiController authApiController = new AuthApiController();
    EmployeeApiController employeeApiController = new EmployeeApiController();
    Employee employee = new Employee();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                authApiController.login("hamo3d.3.2003@gmail.com", "MAma123123#", new ProcessCallBack() {
                    @Override
                    public void onSuccess(String message) {
                        Log.d("login", "onSuccess: " + message);
                        Intent intent = new Intent(getApplicationContext(),TestAddEmployee.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onFailure(String message) {
                        Log.d("somting", "onSuccess: " + message);

                    }
                });
            }
        });

        binding.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),TestGetEmployee.class);
                startActivity(intent);
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();


    }

}