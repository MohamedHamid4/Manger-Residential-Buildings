package com.home_edit.final_project_api_retrofit.views;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.home_edit.final_project_api_retrofit.adpter.employee_adapter.EmployeeViewAdapter;
import com.home_edit.final_project_api_retrofit.api.controllers.EmployeeApiController;
import com.home_edit.final_project_api_retrofit.databinding.ActivityTestGetEmployeeBinding;
import com.home_edit.final_project_api_retrofit.dialoge.DialogFragment;
import com.home_edit.final_project_api_retrofit.enums.ActionType;
import com.home_edit.final_project_api_retrofit.interfaces.ListCalBack;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;
import com.home_edit.final_project_api_retrofit.interfaces.TaskCallBack;
import com.home_edit.final_project_api_retrofit.model.Employee;

import java.util.ArrayList;
import java.util.List;

public class TestGetEmployee extends AppCompatActivity implements TaskCallBack , DialogFragment.OnPositiveClickListener {
    ActivityTestGetEmployeeBinding binding;
    List <Employee> employees = new ArrayList<>();
    EmployeeViewAdapter adapter;
    EmployeeApiController controller;
    int id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTestGetEmployeeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    @Override
    protected void onStart() {
        super.onStart();
        initializeView();
    }

    public void initializeView(){
        setAdapter();
        getEmployee();
    }


    public void setAdapter (){
        adapter = new EmployeeViewAdapter(employees);
        binding.rv.setAdapter(adapter);
        adapter.setCallBack(this::onActionCallBack);
        binding.rv.setLayoutManager(new LinearLayoutManager(this));
    }
    private void getEmployee (){
        controller = new EmployeeApiController();
        controller.getEmployee(new ListCalBack<Employee>() {
            @Override
            public void onSuccess(List<Employee> list) {
                employees.clear();
                employees.addAll(list);
                adapter.notifyItemChanged(0, employees.size());
            }

            @Override
            public void onFailure(String message) {

            }
        });
    }



    @Override
    public void onActionCallBack(ActionType actionType, int positon, int id) {
        if (actionType == ActionType.delete){
            employees.remove(positon);
            adapter.notifyItemRemoved(positon);
            this.id = id;
            deleteEmployee();
        }else if (actionType == ActionType.update){
            DialogFragment fragment = DialogFragment.newInstance("Update Employee");
            fragment.show(getSupportFragmentManager(),null);
            this.id = id;
        }
    }
    private void deleteEmployee(){
        controller = new EmployeeApiController();
        Employee employee = new Employee();
        employee.setId(id);
        controller.delete(employee, new ProcessCallBack() {
            @Override
            public void onSuccess(String message) {

            }

            @Override
            public void onFailure(String message) {

            }
        });
    }
    private void updateEmployee(Employee employee){
        controller = new EmployeeApiController();
        employee.setId(id);
        controller.update(employee, new ProcessCallBack() {
            @Override
            public void onSuccess(String message) {
                adapter.notifyItemRangeInserted(0, employees.size());
                Toast.makeText(TestGetEmployee.this, "tm", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String message) {
                Log.e("onFailure","onFailure: "+message);
            }
        });
    }

    @Override
    public void onPositiveButtOnClicked(String name, String phone, String national) {
        Employee employee = new Employee();
        employee.name = name;
        employee.mobile = phone;
        employee.nationalNumber = national;
        updateEmployee(employee);
    }
}