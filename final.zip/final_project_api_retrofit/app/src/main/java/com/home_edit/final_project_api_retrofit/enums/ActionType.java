package com.home_edit.final_project_api_retrofit.enums;

public enum ActionType {delete,update}
