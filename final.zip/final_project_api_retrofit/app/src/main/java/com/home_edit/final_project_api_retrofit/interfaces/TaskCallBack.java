package com.home_edit.final_project_api_retrofit.interfaces;


import com.home_edit.final_project_api_retrofit.enums.ActionType;

public interface TaskCallBack {
    void onActionCallBack(ActionType actionType , int positon , int id);
}
