package com.home_edit.final_project_api_retrofit.views;

import android.Manifest;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.home_edit.final_project_api_retrofit.R;
import com.home_edit.final_project_api_retrofit.api.controllers.EmployeeApiController;
import com.home_edit.final_project_api_retrofit.databinding.ActivityTestAddEmployeeBinding;
import com.home_edit.final_project_api_retrofit.interfaces.ProcessCallBack;
import com.home_edit.final_project_api_retrofit.model.Employee;

import java.io.ByteArrayOutputStream;

public class TestAddEmployee extends AppCompatActivity implements View.OnClickListener {
    ActivityTestAddEmployeeBinding binding;
    EmployeeApiController employeeApiController = new EmployeeApiController();
    private ActivityResultLauncher<String> permissionResultLauncher;
    private ActivityResultLauncher<Void> cameraResultLauncher;
    private Bitmap imageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTestAddEmployeeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                employeeApiController.createEmployee(binding.name.getText().toString(),Long.parseLong(binding.mopile.getText().toString()),Long.parseLong(binding.nationalNumber.getText().toString()),bitmapToBytes() , new ProcessCallBack() {
                    @Override
                    public void onSuccess(String message) {
                        Toast.makeText(TestAddEmployee.this, message, Toast.LENGTH_SHORT).show();
                        finish();
                    }

                    @Override
                    public void onFailure(String message) {
//                        Toast.makeText(TestAddEmployee.this, "hgello", Toast.LENGTH_SHORT).show();


                        Employee employee = new Employee();
                        Toast.makeText(TestAddEmployee.this, message + binding.mopile.getText().toString(), Toast.LENGTH_SHORT).show();

                    }
                });
            }
        });
        initializeView();

    }

    private void initializeView() {
        setupResultsLauncher();
        setOnClickListeners();
    }


//    private boolean checkData (){
//
//    }
//
//    private void performDtat (){
//        if ()
//    }

    private void setOnClickListeners() {
        binding.picshr.setOnClickListener(this);
    }

    private void pickImage() {
        permissionResultLauncher.launch(Manifest.permission.CAMERA);
    }

    private void setupResultsLauncher() {
        permissionResultLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback<Boolean>() {
            @Override
            public void onActivityResult(Boolean result) {
                if (result) {
                    cameraResultLauncher.launch(null);
                }
            }
        });

        cameraResultLauncher = registerForActivityResult(new ActivityResultContracts.TakePicturePreview(), new ActivityResultCallback<Bitmap>() {
            @Override
            public void onActivityResult(Bitmap result) {
                if (result != null) {
                    imageBitmap = result;
                    binding.imageView.setImageBitmap(imageBitmap);

                }
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.picshr) {
            pickImage();
        }
    }


    private byte[] bitmapToBytes() {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

}